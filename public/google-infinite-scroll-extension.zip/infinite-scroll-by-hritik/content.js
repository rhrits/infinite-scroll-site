let isLoading = false;
let debounceTimeout;
let infiniteScrollEnabled = true;

const debounce = (func, wait) => {
  return function(...args) {
    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(() => func.apply(this, args), wait);
  };
};

const loadMoreContent = async () => {
  if (!infiniteScrollEnabled) return;

  const nextButton = document.querySelector('#pnnext');
  if (nextButton) {
    const nextUrl = nextButton.href;

    try {
      const response = await fetch(nextUrl);
      const text = await response.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(text, 'text/html');

      const newResults = doc.querySelectorAll('.g'); // Select all search result elements
      const container = document.querySelector('#rso'); // Main container for search results

      newResults.forEach(result => {
        container.appendChild(result);
      });

      // Update next button
      const newNextButton = doc.querySelector('#pnnext');
      if (newNextButton) {
        nextButton.href = newNextButton.href;
      } else {
        nextButton.remove();
      }
    } catch (error) {
      console.error('Error loading more content:', error);
    }
  } else {
    console.log('No more pages to load.');
  }
};

const checkAndLoadMore = () => {
  if (isLoading || !infiniteScrollEnabled) return;

  const scrollHeight = document.documentElement.scrollHeight;
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  const clientHeight = window.innerHeight || document.documentElement.clientHeight;

  if (scrollTop + clientHeight >= scrollHeight - 300) {
    isLoading = true;
    loadMoreContent().then(() => {
      isLoading = false;
    });
  }
};

// Initialize infinite scroll based on saved setting
chrome.storage.sync.get('infiniteScrollEnabled', (data) => {
  infiniteScrollEnabled = data.infiniteScrollEnabled !== false;
  window.addEventListener('scroll', debounce(checkAndLoadMore, 200));
});

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'toggleInfiniteScroll') {
    infiniteScrollEnabled = request.enabled;
  }
});
