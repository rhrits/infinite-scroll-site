document.addEventListener('DOMContentLoaded', () => {
    const toggleScroll = document.getElementById('toggleScroll');
  
    // Load saved setting
    chrome.storage.sync.get('infiniteScrollEnabled', (data) => {
      toggleScroll.checked = data.infiniteScrollEnabled !== false;
    });
  
    // Add event listener to the checkbox
    toggleScroll.addEventListener('change', (event) => {
      const isEnabled = event.target.checked;
      chrome.storage.sync.set({ infiniteScrollEnabled: isEnabled });
  
      // Inform the content script of the change
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: toggleInfiniteScroll,
          args: [isEnabled]
        });
      });
    });
  
    // Function to enable/disable infinite scroll
    function toggleInfiniteScroll(isEnabled) {
      window.infiniteScrollEnabled = isEnabled;
    }
  });
  